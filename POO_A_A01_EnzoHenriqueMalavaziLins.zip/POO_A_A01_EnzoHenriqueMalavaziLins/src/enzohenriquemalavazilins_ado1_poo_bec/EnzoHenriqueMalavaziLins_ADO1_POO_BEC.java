/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package enzohenriquemalavazilins_ado1_poo_bec;
import java.util.*;
import java.io.*;

/**
 *
 * @author enzoh
 * version 3
 * Date: 08/03/2022
 * 
 */
public class EnzoHenriqueMalavaziLins_ADO1_POO_BEC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
              // nome do arquivo
        String nomeDoArquivo1 = "C:/Users/enzoh/Documents/pib.txt";
        String arquivoDeSaida = "C:/Users/enzoh/Documents/saida.txt";
        String regioes = "C:/Users/enzoh/Documents/POO_ADO01_EnzoHenrique/Regioes.txt";




/*      ------------------------------------- */
/*      Abertura de arquivo e loop de leitura */
/*      ------------------------------------- */


String estado_sep = null;
float pib = 0;
float pib_pct = 0;
String linha = null;   // linha temporaria
ArrayList<String> estado = new ArrayList<String>();
float pib_tot = 0;
        try {
            FileReader fileReader = new FileReader(nomeDoArquivo1);

            BufferedReader bufferedReader = new BufferedReader(fileReader);
            // loop por cada linha do arquivo


            while((linha = bufferedReader.readLine()) != null) {
            estado.add(linha);
            pib_tot += Float.parseFloat(linha.split(";")[1]);

           }
            //System.out.println("  Pib é : "+ pib_tot );

            for(int i =0; i< estado.size();i++){
            pib = Float.parseFloat(estado.get(i).split(";")[1]);
            //System.out.println(pib);
            pib_pct = (pib*100)/pib_tot;
            estado_sep = estado.get(i).split(";")[0];
            System.out.println("O estado é: "+ estado_sep +" seu PIB é " + pib_pct);

            }

            // feche o arquivo
            bufferedReader.close();

        }
        catch(FileNotFoundException ex) {
            System.out.println("Arquivo inexistente: '" + nomeDoArquivo1 + "'");
        }
        catch(IOException ex) {
            System.out.println("Erro lendo o arquivo '" + nomeDoArquivo1 + "'");
        }


float pib_regiao = 0;
try{
         ArrayList<String> regioes_lista = new ArrayList<String>();
        ArrayList<String> lista_linhas = new ArrayList<String>();

        FileReader fr = new FileReader(regioes);
        BufferedReader br = new  BufferedReader(fr);
        FileWriter fw = new FileWriter(arquivoDeSaida);
        BufferedWriter bw = new BufferedWriter(fw);



        while((linha = br.readLine())!= null){
            lista_linhas.add(linha);
           }
           lista_linhas.add("");

        for(int i = 0; i<lista_linhas.size(); i++){
        if(lista_linhas.get(i).isEmpty()){
         pib_regiao = 0;   
        
            for(int a = 0; a<estado.size();a++){
            for(int b = 0; b < regioes_lista.size();b++){
                if(regioes_lista.get(b).equals(estado.get(a).split(";")[0])){
                pib_regiao += Float.parseFloat(estado.get(a).split(";")[1]);
}
}
}
   bw.write("Pib da regiao "+ regioes_lista.get(0)+" : " + pib_regiao+"\n"); 
    regioes_lista.clear();
    }else{
       regioes_lista.add(lista_linhas.get(i));          
 }
   
}

    br.close();
    bw.close();

        } catch(Exception ex) {
            System.out.println("Erro!");
        }
    }
    
}
