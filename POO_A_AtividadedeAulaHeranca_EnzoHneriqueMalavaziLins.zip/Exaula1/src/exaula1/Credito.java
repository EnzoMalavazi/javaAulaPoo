/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exaula1;

import java.util.ArrayList;

/**
 *
 * @author enzoh
 */
public class Credito extends Cartão{

public Credito(String tipo_pagamento,ArrayList<Integer> precos, String pagar_agora){
    super(tipo_pagamento, precos, pagar_agora);

    }


public int pagar_cred(ArrayList<Integer> prices, String tipo_pagamento, String pagar_agora){
int price = 0;
if("Crédito".equals(tipo_pagamento)){
    if("sim".equals(pagar_agora)){
       return prices.get(0);
    }else{
        for(int i = 0; i < prices.size(); i++){
        price += prices.get(i); 
    }
}

}
return price;
}


}
