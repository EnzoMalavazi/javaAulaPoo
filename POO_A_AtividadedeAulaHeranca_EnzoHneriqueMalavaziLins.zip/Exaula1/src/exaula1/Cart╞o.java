/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exaula1;

/**
 *
 * @author enzoh
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author enzoh
 */
import java.util.ArrayList;

public class Cartão {

private ArrayList<Integer> precos = new ArrayList<Integer>();
private String tipo_pagamento;
private String pagar_agora;



public Cartão(String tipo_pagamento,ArrayList<Integer> precos, String pagar_agora){
    this.precos = precos;
    this.tipo_pagamento = tipo_pagamento;
    this.pagar_agora = pagar_agora;
    
}

public void setPagamento(String tipo_pagamento){
this.tipo_pagamento = tipo_pagamento;

}
public String getPagamento(){
return tipo_pagamento;

}

public void setPreco(String tipo_pagamento){
this.precos = precos;

}

public ArrayList<Integer> getPreco(){
return precos;
}

public int pagar_debit(int price, String tipo_pagamento){
if(tipo_pagamento == "Débito"){
    return price;
}else{
return 0;
}
}
public int pagar_cred(ArrayList<Integer> prices){
int price = 0;
if("Crédito".equals(tipo_pagamento)){
    if("sim".equals(pagar_agora)){
       return prices.get(0);
    }else{
        for(int i = 0; i < prices.size(); i++){
        price += prices.get(i); 
    }
}

}
return price;
}  


 
}

