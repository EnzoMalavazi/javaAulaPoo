/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exaula1;

/**
 *
 * @author enzoh
 */

import java.util.ArrayList;
public class Debito extends Cartão{
    
    /**
     *
     */


    public Debito(String tipo_pagamento,ArrayList<Integer> precos, String pagar_agora){
    super(tipo_pagamento, precos, pagar_agora);

}

@Override
public int pagar_debit(int price, String tipo_pagamento){
if(tipo_pagamento == "Débito"){
    return price;
}else{
return 0;
}


}




}