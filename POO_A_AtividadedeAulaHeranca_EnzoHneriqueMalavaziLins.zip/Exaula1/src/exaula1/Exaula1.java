/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exaula1;

/**
 *
 * @author EnzoHenrqueMalavaziLins
 * @version 1.0
 * Date: 27/03/2022
 */

import java.util.ArrayList;


public class Exaula1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    ArrayList<Integer> precos = new ArrayList<Integer>();

      precos.add(41);
      precos.add(1);

   Credito aa = new Credito("Crédito", precos, "no");
    int b = aa.pagar_cred(precos, "Crédito", "NO");

  System.out.println(b);

Debito teste2 = new Debito("Débito", precos, "sim");
     int c  = teste2.pagar_debit(41,"Débito");
  System.out.println(c);

    }
    
}
